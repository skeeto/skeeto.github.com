#!/usr/bin/octave -qf
## Generates the weight matrix for the points stored in "points.txt" and
## writes it to travel.dat.

## Get the data
pts = dlmread("points.txt");
size = length(pts);

## Generate the weight matrix
for i = 1:size
  for j = 1:size
    weights(i, j) = round(sqrt( ...
			       (pts(i,1) - pts(j,1))^2 + ...
			       (pts(i,2) - pts(j,2))^2 ));
  end
end

## Write to the weight matrix file
outfile = fopen("travel.dat", 'w');
fprintf(outfile, '%d\n', size);
fclose(outfile);
dlmwrite('travel.dat', weights, ' ', '-append');
