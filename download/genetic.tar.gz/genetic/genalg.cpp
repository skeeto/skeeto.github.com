/* genalg.cpp - Genetic Algorithm class
 * Copyright (C) 2007 Christopher Wellons <ccw129@psu.edu>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301, USA.
 */

#include "genalg.h"
#include <math.h>
#include <iostream>
using namespace std;

/*------------------------------------------------------------------*/
/* Constructor and destructor functions
 */

GenAlg::GenAlg(unsigned int (*fit_func)(void*), int size,
	       int num_chromo,
	       double crossover_p, double mutation_p)
{
  this->crossover_p = crossover_p;
  this->mutation_p = mutation_p;
  this->fit_func = fit_func;
  
  pop_size = num_chromo;
  chromo_size = ((int)((size + 1) / 2) * 2);
  
  init_population();
}
  
GenAlg::GenAlg(unsigned int (*fit_func)(void*), int size, int num_chromo)
{
  crossover_p = 0.7;
  mutation_p = 0.001;

  this->fit_func = fit_func;

  pop_size = num_chromo;
  chromo_size = ((int)((size + 1) / 2) * 2);
  
  init_population();
}

void GenAlg::init_population()
{
  // Clear statistical data
  generations = 0;
  mutations = 0;
  
  // Clear best case data
  best_fit = 0;
  best_chromo = new char[chromo_size];
  
  // Create propulation array
  population = new chromosome*[pop_size];
  next_pop   = new chromosome*[pop_size];
  
  // Build initial random population one byte at a time
  for (int i = 0; i < pop_size; i++)
    {
      population[i] = new chromosome;
      next_pop[i]   = new chromosome;
      
      // Fill with random bits
      population[i]->bits = new unsigned char[chromo_size];
      next_pop[i]->bits   = new unsigned char[chromo_size];
      for (int j = 0; j < chromo_size; j++)
	{
	  population[i]->bits[j] = (char)(rand() % 256);
	}
    }
  
  // Update chromosome fitness
  get_fitness();
}

void GenAlg::randomize()
{
  // Fill with random bits
  for (int i = 0; i < pop_size; i++)
    {
      for (int j = 0; j < chromo_size; j++)
	{
	  population[i]->bits[j] = 
	    (unsigned char)(rand() % 256);
	}
    }
}

GenAlg::~GenAlg()
{
  // Delete all allocated data. All of these are allocated in the
  // constructor.
  
  delete [] best_chromo;
  
  for (int i = 0; i < pop_size; i++)
    {
      delete [] population[i]->bits;
      delete [] population[i];
      
      delete [] next_pop[i]->bits;
      delete [] next_pop[i];
    }
  
  delete [] population;
  delete [] next_pop;
}

/*------------------------------------------------------------------*/
/* Function methods
 */

// ***************************************************************
// ********************* EVOLVE FUNCTION *************************
// ***************************************************************
void *GenAlg::evolve()
{
  generations++;
  
  // Now crossover
  unsigned char *pair[2];
  for (int i = 0; i < pop_size; i += 2)
    {
      spin_wheel(pair);
      crossover(pair[0], pair[1],
		next_pop[i]->bits, next_pop[i+1]->bits);
    }
  
  // Now swap old population for new population
  chromosome **swap_var;

  swap_var = population;
  population = next_pop;
  next_pop = swap_var;
  
  // Now find best string and return it while updating fitness table
  unsigned char *result = get_fitness();
  return (void *)result;
}
// ***************************************************************
// ***************************************************************
// ***************************************************************

// Crossover two bit strings and make two new ones
void GenAlg::crossover(unsigned char *mom, 
		       unsigned char *dad, 
		       unsigned char *boy, 
		       unsigned char *girl)
{
  // Determine if split will be done
  double cross_prob = rand() * 1.0 / RAND_MAX;
  bool do_split = cross_prob > crossover_p;

  int num_bits = chromo_size * 8;
  int split_bit = (rand() % (num_bits - 1)) + 1;
  if (do_split)
    split_bit = 0;
  
  int split = split_bit / 8;
  
  // Handle non-split bits
  for (int i = 0; i < split; i++)
    {
      boy[i] = mom[i];
      girl[i] = dad[i];
    }

  for (int i = split + 1; i < chromo_size; i++)
    {
      boy[i] = dad[i];
      girl[i] = mom[i];
    }
  
  // Now handle the split bit
  char mask = ~0; // (all 1's)
  if (do_split)
    {
      mask = mask >> (split_bit % 8);
      
      boy[split]  = (mom[split] & ~mask) + (dad[split] & mask);
      girl[split] = (dad[split] & ~mask) + (mom[split] & mask);
    }
  
  // Now mutate
  char bmut, gmut;
  for (int i = 0; i < chromo_size; i++)
    {
      bmut = 0;
      gmut = 0;
      for (int j = 0; j < 8; j++)
	{
	  // Turn bits on
	  if (rand() * 1.0 / RAND_MAX <= mutation_p)
	    {
	      bmut += (char)pow(2.0, j);
	      mutations++;
	    }
	  if (rand() * 1.0 / RAND_MAX <= mutation_p)
	    {
	      gmut += (char)pow(2.0, j);
	      mutations++;
	    }
	}
      
      // Mutate (flip)
      boy[i]  = boy[i]  ^ bmut;
      girl[i] = girl[i] ^ gmut;

    }
}

void GenAlg::spin_wheel(unsigned char **pair)
{
  // Clear the pair of chromosome pointers (easier error checking
  // later)
  pair[0] = NULL;
  pair[1] = NULL;
  
  // Select the first chromosome
  unsigned int selected = rand() % total_fitness;
  unsigned int sub_chunk = 0;
  for (int i = 0; i < pop_size; i++)
    {
      if (selected <= population[i]->wheel_tick)
	{
	  pair[0] = population[i]->bits;
	  sub_chunk = population[i]->fitness;
	  break;
	}
    }
  
  // Select a second chromosome (cut out the first one from being
  // selected so we don't clone)
  selected = rand() % (total_fitness - sub_chunk);
  unsigned int subtract = 0;
  for (int i = 0; i < pop_size; i++)
    {
      if (population[i]->bits == pair[0])
	{
	  subtract = sub_chunk;
	}
      else
	{
	  if (selected <= population[i]->wheel_tick - subtract)
	    {
	      pair[1] = population[i]->bits;
	      break;
	    }
	}
    }
}

unsigned char *GenAlg::get_fitness()
{
  // Clear best chromosome data
  total_fitness = 0;
  unsigned int best_fitness = 0;
  unsigned char *best_bits = NULL;
  
  unsigned int cur_fitness;
  for (int i = 0; i < pop_size; i++)
    {
      // Call the function pointed to by the function pointer
      cur_fitness = (*fit_func)((void *)population[i]->bits);
      population[i]->fitness = cur_fitness;
      total_fitness += cur_fitness;
      
      // Use in selecting chromosomes for crossover later
      population[i]->wheel_tick = total_fitness;
      
      // Check best for this population
      if (i == 0)
	{
	  best_fitness = population[i]->fitness;
	  best_bits = population[i]->bits;
	}
      else
	{
	  if (population[i]->fitness > best_fitness)
	    {
	      best_fitness = population[i]->fitness;
	      best_bits = population[i]->bits;
	    }
	}
    }
  
  // Check overall best chromosome in any population
  if (best_fitness > best_fit)
    {
      for (int j = 0; j < chromo_size; j++)
	{
	  // Make a copy of it as pointing to it won't work.
	  best_chromo[j] = best_bits[j];
	  best_fit = best_fitness;
	}
    }
  
  return best_bits;
}

void GenAlg::print()
{
  unsigned char cur_char;
  
  // Print each byte one at a time
  for (int i = 0; i < pop_size; i++)
    {
      for (int j = 0; j < chromo_size; j++)
	{
	  cur_char = population[i]->bits[j];
	  for (int k = 0; k < 8; k++)
	    {
	      cout << cur_char % 2;
	      cur_char /= 2;	  
	    }
	}
      cout << ", " << population[i]->fitness << endl;
    }
}
