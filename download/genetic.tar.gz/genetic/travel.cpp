/* travel.cpp - Traveling Salesman Problem w/ a Genetic Algorithm
 * Copyright (C) 2007 Christopher Wellons <ccw129@psu.edu>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301, USA.
 */

#include "genalg.h"
#include <iostream>
#include <fstream>
#include <math.h>
#include <ctime>
using namespace std;

int **weights;          // weight matrix
unsigned int num_nodes; // number of vertices

int num_chromo = 40;    // number of chromosomes
double cross_p = 0.7;   // crossover probability
double mut_p   = 0.01;  // mutation probability
int loops = 10000000;   // loops
int check = 10000;      // how often we check on things

bool *node_check;       // used in the fitness function
unsigned int  max_val;  //
unsigned char *out;     //
unsigned int  rnodes;   //

// Circular queue structure
typedef struct node_t 
{
  int data;
  struct node_t *next;
} node_t;

node_t *node_pool;      // Circular queue
node_t **node_array;    // Use this so we only allocate once per node
int    node_count;      // count nodes in queue

unsigned char gmask = (~0 << 4); // msb bit mask
unsigned char lmask = ~gmask;    // lsb bit mask

void load_file(char *filename);   // load weight matrix from file
unsigned int path_len(void *);    // fitness function
unsigned char *expand(unsigned char *);

void init_queue();      // queue functions
void reset_queue();     // reset the queue
int  pop_queue(int n);  // pop the nth item from the queue

int main()
{
  // set the random generator seed
  srand((unsigned)time(0));
  
  // load the weights
  cout << "Loading weight matrix ... ";
  load_file("travel.dat");
  cout << "done!" << endl;
  
  // Initialize the circular queue
  init_queue();
  
  // allocate space needed for fitness function
  cout << "Setting up variables ... ";
  node_check = new bool[num_nodes];
  //max_val = (int)(pow(2.0, sizeof(int)*8) / num_chromo); // abs max
  max_val = 10000; // arbitrary max
  rnodes = ((num_nodes + 1) / 2) * 2;
  out = new unsigned char[rnodes];
  cout << "done!" << endl;
  
  // create a new genetic algorithm object
  cout << "Setting up GenAlg object ... ";
  GenAlg ga(&path_len, rnodes / 2, num_chromo, cross_p, mut_p);
  cout << "done!" << endl;

  ofstream outfile;
  ofstream bestfile;
  ofstream plotfile;
  plotfile.open("plot.txt");
  bestfile.open("best.txt");
  for (int i = 0; i < loops; i++)
    {
      void *cur_best = ga.evolve();
      
      if (i % check == 0 && i > 0)
	{
	  ga.print();
	  
	  cout << i*100.0/loops << "%:\t" 
	       << (max_val - ga.best_fit) << endl;
	  
	  bestfile << (max_val - ga.best_fit) << endl;
	  plotfile << (max_val - path_len(cur_best)) << endl;
	  
	  // Output best known path
	  expand((unsigned char *)ga.best_chromo);
	  outfile.open("path.txt");
	  reset_queue();
	  for (unsigned int i = 0; i < num_nodes; i++)
	    {
	      outfile << pop_queue(out[i]) << endl;
	    }
	  outfile.close();
	}
    }
  plotfile.close();
  
  // Output final result
  cout << "Best Fitness: " << (max_val - ga.best_fit) << endl;
  
  delete [] out;
  
  return 0;
}

void load_file(char *filename)
{
  ifstream infile;
  infile.open(filename);
  
  // Get the number of vertices
  infile >> num_nodes;
  
  // Allocate the space
  weights = new int*[num_nodes];
  for (unsigned int i = 0; i < num_nodes; i++)
    weights[i] = new int[num_nodes];
  
  // Load the data
  for (unsigned int i = 0; i < num_nodes; i++)
    for (unsigned int j = 0; j < num_nodes; j++)
      infile >> weights[i][j];
  
  infile.close();
}

unsigned int path_len(void *vset)
{
  // Grab the data
  unsigned char *set = expand((unsigned char*)vset);
  
  // Built the node pool
  reset_queue();
  
  // Calculate the path length
  unsigned char last_node = 0;
  unsigned char cur_node = 0;
  int total = 0;
  for (unsigned int i = 0; i < num_nodes; i++)
    {
      // Figure out which node is next
      cur_node = pop_queue(set[i]);
      
      if (i > 0)
	total += weights[last_node][cur_node];
      
      last_node = cur_node;
    }
  
  return (max_val - total);
}

unsigned char *expand(unsigned char *in)
{
  for (unsigned int i = 0; i < rnodes; i += 2)
    {
      out[i]     = (in[i/2] >> 4) & lmask;
      out[i + 1] = (in[i/2] & lmask);
    }
  
  return out;
}

void init_queue()
{
  node_array = new node_t*[num_nodes];
  
  for (unsigned int i = 0; i < num_nodes; i++)
    {
      node_array[i] = new node_t;
      node_array[i]->data = i;
    }
}

void reset_queue()
{
  node_count = num_nodes;
  
  for (unsigned int i = 0; i < (num_nodes - 1); i++)
    {
      node_array[i]->next = node_array[i+1];
    }
  
  // Point last item to the first
  node_array[num_nodes - 1]->next = node_array[0];

  // Put the iterator at the beginning
  node_pool = node_array[0];
}

int pop_queue(int n)
{
  // Don't loop more than necessary
  n = (n % node_count) + 1;
  
  // Iterate through the queue
  node_t *last = NULL;
  for (int i = 0; i < n; i++)
    {
      last = node_pool;
      node_pool = node_pool->next;
    }
  
  // grab the data
  int cur_data;
  cur_data = node_pool->data;
  
  // cut out the current node
  last->next = node_pool->next;
  node_pool = node_pool->next;
  
  node_count--;
  return cur_data;
}
