/* genalg.h - Genetic Algorithm
 * Copyright (C) 2007 Christopher Wellons <ccw129@psu.edu>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301, USA.
 */

/* This is a genetic algorithm class that will work with any given
 * datatype that doesn't rely on pointers (except arrays). The user
 * provides a pointer to a fitness function and the problem data
 * size. The genetic algorithm class will return a void pointer to its
 * results, which you can recast to get your data. It doesn't care
 * about the structure of your data.
 *
 * Your fitness function must accept a void pointer (to the data to be
 * evaluated) and returns an unsigned integer, which cannot be equal
 * to 0.
 *
 * Note: Your fitness function should avoid returning values greater
 * than (unsigned_integer_max / num_chromosomes). This way if each
 * chromosome has the highest possible fitness, the integer won't
 * overflow when adding these all together.
 *
 * Also, the number of chromosomes in the population must be an even
 * number. If an odd number is given, it will be rounded up to the
 * nearest even number.
 */

#ifndef GENALG_H
#define GENALG_H

#include <iostream>
#include <math.h>
using namespace std;

class GenAlg
{
public:
  GenAlg(unsigned int (*fit_func)(void*), int size, int num_chromo,
	 double crossover_p, double mutation_p);
  
  // Will automatically choose sensible values for crossover and
  // mutation probabilities
  GenAlg(unsigned int (*fit_func)(void*), int size, int num_chromo);
  
  ~GenAlg();
  
  void *evolve();                // Evolve a new population
  void print();                  // Print chromosomes
  void randomize();              // Generate an entirely new
				 //   population from scratch
  
  unsigned int best_fit;         // Best known chromosome
  char *best_chromo;
  
  unsigned int mutations;        // mutation counter
  unsigned int generations;      // generation counter

private:
  void init_population();        // Initialize the population table
  unsigned char *get_fitness();  // Update the population fitness
  
  void crossover(unsigned char*, // Crossover two bit strings and make
		 unsigned char*, // two new ones
		 unsigned char*, //
		 unsigned char*);//  
  
  void spin_wheel(unsigned 
		  char **);      // Chooses two chromosomes based on
				 // fitness.

  // struct to keep track of chromosomes
  typedef struct chromosome
  {
    unsigned char *bits;
    unsigned int fitness;
    unsigned int wheel_tick;
  } chromosome;
  
  int pop_size;                  // Poplation data
  int chromo_size;               //
  chromosome **population;       //
  chromosome **next_pop;         //
  unsigned int total_fitness;    //
  
  double crossover_p;            // Algorithm parameters
  double mutation_p;             //
  
  unsigned                       // Fitness function pointer
  int (*fit_func)(void*);        //

};

#endif
