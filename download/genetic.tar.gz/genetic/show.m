#!/usr/bin/octave -qf
## Use this to show the data for the Traveling Salesman Problem program.
while (1)
  ## Get the data
  inpts = dlmread("points.txt");
  outpts = dlmread("path.txt") + 1;
  
  ## Prepare the plot
  clf;
  legend('off');
  axis([0 100 0 100], 'square', 'off');
  hold on;
  
  ## plot the data  
  plot(inpts(:,1), inpts(:,2), '*r');
  plot(inpts(outpts(:),1), inpts(outpts(:),2), '-b');
  
  ## Wait a few seconds and refresh
  sleep(1);
end
