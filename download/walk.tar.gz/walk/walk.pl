#!/usr/bin/perl -w
# Walk Front End v0.90 - terminal front end for Walk text-adventure engine
# Copyright (C) 2005 Chris Wellons
# 
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor,
# Boston, MA  02110-1301, USA.

# Set the language:
my $lang;
$lang = "en";

# Set the world filename
my $worldfile;
$worldfile = "$lang/index.txt";

# Initialize the current room name
my $room_name;
$room_name = "";

# Initialize the current room description
my $room_disc;
$room_disc = "";

# Initialize the inventory. Player always starts with backpack.
my %inventory;
$inventory{"Backpack"} = 1;

# Initialize the command string. We use "look" because that will also
# spit out the room description.
my $command;
$command = "help";

# Load the engine
require "walk_engine.pl";

# Loop until the user says "quit"
# User commmand and important information go in. Output to screen 
# comes out along with updates inventory, room name, and room
# description. run_room is the real engine for the game.
while($command ne "quit") {
# Keep track of the room name:
    $old_room = $room_name;

# Run the engine:
    ($out, $room_name, $room_disc, %inventory) = 
	walk_engine::run_room($worldfile, 
			      $lang, 
			      $command, 
			      $room_name, 
			      $room_disc, 
			      %inventory);

    # Automatically do a look command in a new room:
    if ($old_room ne $room_name) {
	wdisp("\n$out\n");
	$command = "look";
	($out, $room_name, $room_disc, %inventory) = 
	    run_room::run_room($worldfile, 
			       $lang, 
			       $command, 
			       $room_name, 
			       $room_disc, 
			       %inventory);
    }

    wdisp("\n$out\n");

    print "Action: ";
    $command = <STDIN>;
    chop($command);

    # 'clc' not handled by the engine
    if ($command eq "clc") {
	print `clear`;
	$command = " ";
    }
}

# Display driver to fit the lines in the terminal:
sub wdisp {
    @text = split(/ /, $_[0]);
    $total = 0;
    foreach $word (@text) {
	$total = $total + length($word) + 1;
	if (index($word, "\n") > -1) { $total = 0; }
	if ($total > 70) { print "\n"; $total = 0; }
	print "$word ";
    }
}
