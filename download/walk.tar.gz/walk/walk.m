% Walk - a text-adventure engine
% Copyright (C) 2005 Chris Wellons
% 
% This program is free software; you can redistribute it and/or
% modify it under the terms of the GNU General Public License
% as published by the Free Software Foundation; either version 2
% of the License, or (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 51 Franklin Street, Fifth Floor, 
% Boston, MA  02110-1301, USA.

% See README for detailed information

% Sorry if the code is inefficient and sloppy. This is the best that could
% be done in MatLab. MatLab is not a very powerful programming language
% when it comes to anything except matrices. It has no pointers and no good
% data structures such as associative arrays which would have been a great
% time and code saver for this program. The lack of pointers prevents the
% building of higher data structures as well so I am stuck with the
% garbage. I would say this is worse than Visual Basic.

function walk(worldfile, lang)
% WALK (world filename, language code)
% Walk v0.99 is a text-adventure program for MatLab.

% Set language. Use this to set what language will be used.
lang = 'en';
% Set worldfile if it wasn't input.
worldfile = [lang,'/index.txt'];

% Open the world file.
world = fopen(worldfile, 'r');

% Clean up the screen
clc;

% Display help
disp_help(lang);
disp(' ');

% Initialize stubborn variables
% This is the reason why the user always has a backpack to begin with.
inventory(1) = cellstr('Backpack');

% Load the main file. We want to look at the file one room at a time and
% not load the entire thing into the memory (no textread). We load the
% current room into the memory and then dump that when the user enters
% another room.

% First, we build a list of all the rooms and their location inside the
% description file so they can be easy jumped to later on.
room_list(1) = cellstr('ROOM'); % Needs to be initialized
room_pos(1)  = 0;
while (~feof(world))
    % Grab the next line but use a vector of words:
    wline = '';
    while (length(wline) == 0)
        pos = ftell(world);
        wline = fgetl(world);
    end
    nline = grab_line(wline);
    
    % If it is a room line, write it down for later
    if strcmp(upper(nline(1)), 'ROOM')
        room_list(numel(room_list) + 1) = nline(2);
        room_pos(numel(room_list)) = pos;
    end
end

% Next, we take the user to the first room and execute that room's code.
% The room engine will return the name of the next room when it is done in
% the current room. The program then loops and runs the next room name. A
% room name of 'quit' means to end the game. Therefore, by telling the game
% to GOTO quit in the world description file it would force the game to
% quit. This would make an interesting hack for the world files.
room_name = char(room_list(2));
room_disc = '';
while ~strcmp(room_name, 'quit')
    pos = find_room(room_name, room_list, room_pos);
    if (pos < 0) 
        wdisp(['Room not found: ', room_name]);
        return;
    end
    fseek(world, pos, 'bof');
    [room_name inventory] = run_room(lang, world, inventory, room_disc);
    room_disc = '';
    inventory = clean_inv(inventory);
    
    if strcmp(room_name, 'load') 
        [lang room_name room_disc inventory] = load_inv();
        wdisp('Restored.');
    end
    
    if strcmp(room_name, 'quit')
        fclose(world);
        % Clear and make bos-screen.
        clc;
        whos;
        return;
    end
end

% Close the world file before the program ends.
fclose(world);

%--------------------------------------------------------------------------
% Turns the text into a 2 element vector.
function nline = grab_line(wline)
% Get a list of the whitespace delimiting and break into a vector
% accordingly.
slist = findstr(wline, ' ');    % find spaces
tlist = findstr(wline, '	'); % find tabs
wslist = [slist tlist];
wslist = sort(wslist); % Combine and sort tabs and spaces

wslist(numel(wslist) + 1) = length(wline);

st_line = 1;
i = 0;
found_kw = 0;
while(found_kw == 0 && i < numel(wslist))
    i = i + 1;
    if (wslist(i) - st_line > 1 && length(wline(st_line:wslist(i))) > 0)
        nline(1) = cellstr(wline(st_line:wslist(i)));
        found_kw = 1;
    end
    st_line = wslist(i) + 1;
end
if ~(wline == -1)
    nline(2) = cellstr(wline(st_line:length(wline)));
else
    nline(2) = cellstr('abcdef');
end
%--------------------------------------------------------------------------
% Executes the room at the current file position.
function [room_name inventory] = run_room(lang, world, inventory, room_disc)
% Load keywords:
actList = textread([lang,'/actions.txt'], '%s');
act(1,1) = cellstr(' ');
for i = 1:numel(actList)
    fid = fopen([lang,'/',lower(char((actList(i)))),'.txt'], 'r');
    j = 0;
    if fid > -1
        while ~feof(fid)
            j = j + 1;
            act(i,j) = cellstr(fgetl(fid));
        end
        fclose(fid);
    else
        disp(['Could not find file: ', lang,'/',lower(char((actList(i)))) ...
              ,'.txt']);
    end
end

% Initialize
loadMode = 0;
if length(room_disc) > 1
    loadMode = 1;
end
room_name = 'NO NAME - Error in World File';
object_count = 0;

% Loop until the code finds ENDROOM or until the end of the file, which
% should never ever happen. This section loads the room into the memory.
while(~feof(world))

% Grab the next line but use a vector of words:
wline = '';
while (length(wline) == 0)
    wline = fgetl(world);
end
nline = grab_line(wline);

% Save all the data for this room to memmory:
switch upper(char(nline(1)))
    case('ROOM')
        room_name = nline(2);
    case('DISC')
        if ~loadMode
            room_disc = [room_disc,' ',char(nline(2))];
        end
    case('OBJECT')
        % Add the object to memmory:
        object_count = object_count + 1;
        object(object_count) = nline(2);
        % Set the number of actions on the object:
        object_act_ct(object_count) = 0;
        command_count = 0;
    case('ACTION')
        % Set the number of actions on the object:
        object_act_ct(object_count) = object_act_ct(object_count) + 1;
        object_action(object_count, object_act_ct(object_count), 1) ...
            = nline(2);
        % Reset the command count
        command_count = 1;
    case{'DISP', 'TAKE', 'GIVE', 'REQUIRE', 'REQUIRENOT', 'GOTO', ...
         'CLEARDISC', 'NEWDISC', 'REQUIRECOM', 'REQUIRECOMNOT'}
        if command_count == 0
            wdisp('Error at position:');
            disp(ftell(world));
            disp(nline);
            disp('Execution line before ACTION line.');
            command = 'quit';
            room_name = 'quit';
            return;
        end
        command_count = command_count + 1;
        object_action(object_count, object_act_ct(object_count), ...
                      command_count) = upper(nline(1));
        command_count = command_count + 1;
        object_action(object_count, object_act_ct(object_count), ...
                      command_count) = nline(2);
    case('ENDROOM')
        break;
    otherwise
        disp(['Strange command found: ',char(nline(1))]);
end

end

% Display the current room description:
wdisp(room_disc);

% Ask the user what to do. This is the driving part of the engine.
command = ' ';
while ~strcmp(command, 'quit')
% Turns true if the command was recognized. If it is false at the end of
% execution, one of those error messages is produced: "You can't do that."
doneFlag = 0;
command = lower(input('Action: ', 's'));
% All commands are set to lower case so they are no case sensitive.
disp(' ');

% If the command is nill, dont display an error.
if length(command) < 2
    doneFlag = 1;
end

% Check for special commands
switch command
    case('quit')
        % Quit
        room_name = 'quit';
        doneFlag = 1;
        break;
    case{'help','doc'}
        % Display help
        disp_help(lang);
        doneFlag = 1;
    case('save')
        % Save
        save_inv(lang, room_name, room_disc, inventory);
        wdisp('Saved.');
        doneFlag = 1;
    case('clc')
        % clc - Clear screen
        clc;
        doneFlag = 1;
    case('load')
        % Load
        room_name = 'load';
        doneFlag = 1;
        break;
    case('inv')
        % Show the inventory
        doneFlag = 1;
        for i = 1:numel(inventory)
            if numel(findstr(char(inventory(i)),':')) == 0
                wdisp(char(inventory(i)));
            end
        end
    case('invall')
        % Show the entire inventory (cheat)
        doneFlag = 1;
        for i = 1:numel(inventory)
            wdisp(char(inventory(i)));
        end
    case{'look', 'ls'}
        wdisp(room_disc);
        doneFlag = 1;
end

% Find if action words are present:
% First set all action flags to 0. This also initializes them if it is the
% first run.
for i = 1:numel(actList)
    actFlag(i) = logical(0);
end
for i = 1:numel(actList)
    for j = 1:size(act,2);
        if iscellstr(act(i,j)) && ~numel(findstr(command, char(act(i,j)))) ...
              == 0;
            actFlag(i) = logical(1);
        end
    end
end

% Create strings of execution code to step through. This looks pretty neat.
exe_ct = 0;
for i = 1:size(object_action,1)
    if (numel(findstr(lower(char(object(i))), command)) > 0)
        for j = 1:size(object_action,2)
            for k = 1:numel(actList)
                if (strcmp(object_action(i,j,1),actList(k)) && actFlag(k))
                    exe_ct = exe_ct + 1;
                    % Nothing new is created. It simply lists where
                    % execution will need to be done by index value. The
                    % action data structure is a three dimensional matrix.
                    % Objects are listed vertically. Actions are listed
                    % horizontally, and execution lines are listed in
                    % depth. We make a list of spots in the front surface
                    % of this block and execution travels into the block
                    % from that point.
                    exe_i(exe_ct) = i;
                    exe_j(exe_ct) = j;
                end
            end
        end
    end
end

% Step through each execution string:
dispout = '';
if (exe_ct > 0)
    for i = 1:exe_ct
        % Boolean pass sets to 0 if a requirement is not met.
        % Requirments are passed by default. Innocent until proven guilty.
        pass = 1;
        for x = 2:2:numel(object_action(exe_i(i), exe_j(i), :))
            comm = object_action(exe_i(i), exe_j(i), x);
            arg  = object_action(exe_i(i), exe_j(i), x + 1);
            % Make sure we didn't run out of code:
            if ~iscellstr(comm)
                break;
            end
            % If we fail requirements, the command disappears making
            % further execution impossible. This is a sloppy way to do
            % this.
            if ~pass
                comm = ' ';
            end
            % Look for commands:
            switch char(comm)
                case('REQUIRE')
                    % Check inventory for item.
                    pass = 0;
                    for s = 1:numel(inventory)
                        if strcmp(inventory(s), arg)
                            pass = 1;
                        end
                    end
                case('REQUIRENOT')
                    % Check inventory for item.
                    pass = 1;
                    for s = 1:numel(inventory)
                        if strcmp(inventory(s), arg)
                            pass = 0;
                        end
                    end
                case('REQUIRECOM')
                    % Check command for string.
                    pass = 0;
                    if numel(findstr(command, char(arg))) > 0
                        pass = 1;
                    end
                case('REQUIRECOMNOT')
                    % Check command for string.
                    pass = 1;
                    if numel(findstr(command, char(arg))) > 0
                        pass = 0;
                    end
                case('DISP')
                    carg = strrep(char(arg), '\n', '\n');
                    dispout = [dispout,' ',carg];
                    doneFlag = 1;
                case('GIVE')
                    inventory(numel(inventory) + 1) = arg;
                    doneFlag = 1;
                case('TAKE')
                    % The dashes and multiple entries are cleaned up after
                    % the room is exited. I believe the dash offers a nice
                    % feature. It is an indication that someone was taken
                    % away recently.
                    for s = 1:numel(inventory)
                        if strcmp(char(inventory(s)), arg)
                            inventory(s) = cellstr('-');
                        end
                    end
                    doneFlag = 1;
                case('GOTO')
                    % Set the room name and exit from the run_room
                    % function.
                    room_name = arg;
                    command = 'quit';
                    doneFlag = 1;
                case('CLEARDISC')
                    room_disc = '';
                    doneFlag = 1;
                case('NEWDISC')
                    room_disc = [room_disc, ' ', char(arg)];
                otherwise
                    %nothing
            end
        end
    end
end

wdisp(dispout);

% If nothing happenned, then spit out an error message.
if ~doneFlag
    edisp(lang);
end

end
%--------------------------------------------------------------------------
% Returns the location of the given room.
function pos = find_room(room_name, room_list, room_pos)

for i = 1:numel(room_list)
    if (strcmp(lower(room_name), lower(room_list(i))))
        pos = room_pos(i);
        return;
    end
end
pos = -1;

%--------------------------------------------------------------------------
% This is a better display driver that will wrap long lines automatically.
function wdisp(text);
% This number can be edited to make lines wider or thinner.
text_width = 60;

text = strrep(text, '\n', '~');

c = 0;
tbuff = '';
for i = 1:length(text);
    if strcmp(text(i), '~')
        disp(tbuff);
        c = 0;
        tbuff = '';
        disp('  ');
        text(i) = ' ';
    end
    c = c + 1;
    if (c > text_width && text(i) == ' ')
        disp(tbuff);
        c = 0;
        tbuff = '';
    end
    tbuff = [tbuff, text(i)];
end

disp(tbuff);

%--------------------------------------------------------------------------
% Display some error message.
function edisp(lang);
% Grab a list from the language file.
ct = 0;
errf = fopen([lang,'/err.txt']);
while ~feof(errf)
    ct = ct + 1;
    comErr(ct) = cellstr(fgetl(errf));
end
fclose(errf);

wdisp(char(comErr(round(rand*(numel(comErr) - 1) + 1))));

%--------------------------------------------------------------------------
% Display the help message for the given language. This basically dumps the
% initd file out to the screen.
function disp_help(lang);

initd = fopen([lang,'/initd.txt'], 'r');
while ~feof(initd)
    wline = fgetl(initd);
    wdisp(wline);
end
fclose(initd);

%--------------------------------------------------------------------------
% Save the current state. This just dumps the language, current room, and 
% inventory to a file.
function save_inv(lang, room_name, room_disc, inventory)

fsave = fopen('save_state', 'w');
fprintf(fsave, '%s\n', lang);
fprintf(fsave, '%s\n', char(room_name));
fprintf(fsave, '%s\n', room_disc);
for i = 1:numel(inventory);
    fprintf(fsave, '%s\n', char(inventory(i)));
end
fclose(fsave);

%--------------------------------------------------------------------------
% Load the current state. This just grabs the language, current room, and 
% inventory list from a file. Opposite of save.
function [lang room_name room_disc inventory] = load_inv()

fsave = fopen('save_state', 'r');
lang = fgetl(fsave);
room_name = cellstr(fgetl(fsave));
room_disc = fgetl(fsave);
i = 0;
while (~feof(fsave))
    i = i + 1;
    inventory(i) = cellstr(fgetl(fsave));
end
fclose(fsave);

%--------------------------------------------------------------------------
% This return the given array without any dash elements. That is, elements
% that are just '-'. Also remove repeated entries.
function inventory = clean_inv(inventory)

% Remove -'s
for i = 1:numel(inventory)
    % Another reason Matlab is terrible: It stores the original value and
    % doesn't update the for loop on the new numel() value. Other languages
    % like C will check against the most recent value every time so we
    % don't have to use the following if statement.
    if i > numel(inventory) 
        break;
    end
    if strcmp(char(inventory(i)), '-')
        for j = i:(numel(inventory) - 1)
            inventory(i) = inventory(j + 1);
        end
        inventory(numel(inventory)) = [];
    end
end

% Remove double entries
inventory = unique(inventory);

%--------------------------------------------------------------------------
% Overloading the Matlab textread function for systems that do not have it
% already such as Octave. This will not work the same way as the original
% textread but it will work as needed for Walk.
function arrout = textread(file, text)

fin = fopen(file, 'r');

if strcmp(text, '%s')
    i = 0;
    while (~feof(fin))
        i = i + 1;
        arrout(i) = cellstr(fgetl(fin));
    end
end
if strcmp(text, '%u')
    i = 0;
    while (~feof(fin))
        i = i + 1;
        arrout(i) = str2num(fgetl(fin));
    end
end

fclose(fin);
