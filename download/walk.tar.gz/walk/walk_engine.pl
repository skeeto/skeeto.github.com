#!/usr/bin/perl -w
# Walk v0.90 - a text-adventure engine
# Copyright (C) 2005 Chris Wellons
# 
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor,
# Boston, MA  02110-1301, USA.

package walk_engine;
return 1;

sub run_room {
    ($worldfile, 
     $lang, 
     $command, 
     $room_name, 
     $room_disc, 
     %inventory) = @_;

# Initialize $out
    $out = "";

# This flag is turns true if the command was found valid in some way
    $validFlag = 0;

# Check for fresh run.
    $freshRun = 0;
    if ($room_disc eq "") { print $room_disc; $freshRun = 1; }

# Make sure the command is lowercase
    $command = lc($command);

# We begin by loading the action lists.
    # Clear the action list first:
    foreach $item (keys(%action)) { delete $action{$item}; }
# First is the first main action list. Then, if one of the action
# words in a list is found, we add that action to the list.
    open(ACTION, "$lang/actions.txt");
    while (<ACTION>) { 
	chop;
	$action_name = $_; 
	open(WORD, "$lang/" . lc($action_name) . ".txt");
	$addFlag = 0;
	while (!$addFlag && !eof(WORD)) {
	    $fline = <WORD>;
	    chop($fline);
	    if (index($command, $fline) > -1) {
		$action{$action_name} = 1;
		$addFlag = 1;
	    }
	}
	close(WORD);
    }
    close(ACTION);

# Next, we open the word file and find where we need to go:
    open(WORLD, $worldfile);

# Position the file reading at the begginning of the current room
    $notFound = 1;

    while ($notFound) {
	$fline = <WORLD>;
	$notFound = !eof(WORLD);
	if (index($fline, "ROOM") > -1 && index($fline, $room_name) > -1) {
	    $notFound = 0; }
    }

# Error message if the room is not found:
    if ($notFound) {
	print "Room not found!"; }
    
# Now we step through. If we find an object, we see if the user
# invoked that object on the command line. If true, then we start 
# looking for actions. If the action was invoked (it is on the 
# action list), we execute the code for that action. If a requirement
# is failed, then we go back into action mode. If another object is
# found then we go back into object mode.
    $action_mode = 0; # True if we are looking for actions
    $exe_mode = 0;    # True if we are executing code
    $doneRoom = 0;
    while(!$doneRoom) {
	$fline = "\n";
	while (length($fline) < 3) { $fline = <WORLD>; }
	chop($fline);
	# Get rid of tabs and break the line down into an array of words
	$fline =~ s/\t/ /g;
	$fline =~ s/ +/ /g;
	$fline =~ s/\A //g;
	@in_list = split(/ /, $fline);
        # Split the input into $com, the first word, and arg,
	# everything else
	$com = uc(shift(@in_list));
	if ($com eq "ENDROOM") { $doneRoom = 1; }
	$arg = join(" ", @in_list);
	if ($com eq "OBJECT") {
	    $action_mode = 0;
	    $exe_mode = 0;
	    if (index($command, $arg) > -1) {
		$action_mode = 1;
	    }
	}
	if ($action_mode && $com eq "ACTION") {
	    $exe_mode = 0;
	    if ($action{$arg}) { $exe_mode = 1; }
	}
	if ($com eq "DISC" && $freshRun) {
	    $room_disc = "$room_disc $arg"; }
	# See the README file for a description of what these
	# big commands do.
	if ($exe_mode) {
	    if ($com eq "REQUIRE") {
		if (!$inventory{$arg}) { $exe_mode = 0; }
	    }
	    if ($com eq "REQUIRENOT") {
		if ($inventory{$arg}) { $exe_mode = 0; }
	    }
	    if ($com eq "REQUIRECOM") {
		if (index($command, $arg) == -1) { $exe_mode = 0; }
	    }
	    if ($com eq "REQUIRECOMNOT") {
		if (index($command, $arg) > -1) { $exe_mode = 0; }
	    }
	    if ($com eq "GIVE") {
		$inventory{$arg} = 1; 
		$validFlag = 1; }
	    if ($com eq "TAKE" && $inventory{$arg}) {
		delete($inventory{$arg}); 
		$validFlag = 1;}
	    if ($com eq "GOTO") {
		$room_disc = "";
		$room_name = $arg; 
		$validFlag = 1; }
	    if ($com eq "CLEARDISC") {
		$arg = "";
		$validFlag = 1; }
	    if ($com eq "NEWDISC") {
		$room_disc = $room_disc . $arg;
		$validFlag = 1; }
	    if ($com eq "DISP") {
		$arg =~ s/\\n/\n/g;
		$out = "$out $arg"; 
		$validFlag = 1;}
	}
    }

# Always close your files
    close(WORLD);

# Look around
    if ($command eq "look" || $command eq "ls") {
	$out = $room_disc; 
	$validFlag = 1; }

# Display help
    if ($command eq "help" || $command eq "doc") {
	open(HELP, "$lang/initd.txt");
	while (<HELP>) { $out = $out . $_; }
	close(HELP); 
	$validFlag = 1; }

# Display inventory
    if ($command eq "inv") {
	foreach $item (keys(%inventory)) {
	    if (index($item, ":")) { $out = "$out$item\n" }
	}
	$validFlag = 1;
    }

# Display entire inventory (debug)
    if ($command eq "invall") {
	foreach $item (keys(%inventory)) {
	    $out = "$out$item\n"
	}
	$validFlag = 1;
    }

# If there was no valid action, then we output an error message:
    if (!$validFlag && length($command) > 2) {
	open(ERM, "$lang/err.txt");
	while (<ERM>) { push(@err_mess, $_); }
	$out = $err_mess[rand() * @err_mess];
	close(ERM);
    }

# Make sure the last line is a newline. Not sure if this causes
# problems in a DOS end-line based system (Windows)
    if (substr($out, length($out) - 1, 1) ne "\n") { $out = "$out\n"; }

# Return the values.
    return($out, $room_name, $room_disc, %inventory);
}
