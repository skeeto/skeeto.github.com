function makepl(lang)
% MAKEPL Converts the given language world file into pig latin.
% makepl is a pig latin converter. It completely builds a copy of the given
% world's language directory in pig latin as a 'pl' directory.

mkdir('pl');
fl = dir(lang);
for i = 3:size(fl,1)
    infile = fl(i).name;
    if strcmp(infile, 'actions.txt') || strcmp(infile, 'index.txt') || strcmp(infile, 'err.txt') || strcmp(infile, 'initd.txt')
        outname = infile;
    else
        outname = [ret_pl(infile(1:length(infile)-4)), '.txt'];
    end
    con_file([lang,'/',fl(i).name],['pl/',outname]);
    disp([fl(i).name, ' converted to ', ['pl/',outname]]);
end

function con_file(infile, outfile)
fin = fopen(infile, 'r');
fout = fopen(outfile, 'w');

while ~feof(fin)
    wline = fgetl(fin);
    slist = findstr(wline, ' ');    % find spaces
    tlist = findstr(wline, '	'); % find tabs
    wslist = [slist tlist  length(wline)];
    wslist = sort(wslist); % Combine and sort tabs and spaces
    s = 1;
    nwline = '';
    for i = 1:numel(wslist)
        if wslist(i) - s > 1
            if s > 1 && ~(wslist(i) == length(wline))
                word = wline(s+1:wslist(i)-1);
            end
            if s > 1 && wslist(i) == length(wline)
                word = wline(s+1:wslist(i));
            end
            if s == 1 && wslist(i) == length(wline)
                word = wline(s:wslist(i));
            end
            if s == 1 && ~(wslist(i) == length(wline))
                word = wline(s:wslist(i)-1);
            end
            if ~strcmp(upper(word), word)
                newword = ret_pl(word);
            else
                newword = word;
            end
            if ~strcmp(nwline, '')
                nwline = [nwline ' ' newword];
            else
                nwline = newword;
            end
        end
        s = wslist(i);
    end
    if ~(fout == -1)
        fprintf(fout, '%s\n', nwline);
    end
end

fclose(fin);
if ~(fout == -1)
    fclose(fout);
end

function pl = ret_pl(text);

pl = [text(2:length(text)) text(1) 'ay'];


