#include "main.h"
#include "prim_func.h"
#include "setup.h"

/* Sensor data */
int bright_dat[] = { 121, 103, 90, 80, 70, 63, 57, 53, 48, 46, 0 };
int fright_dat[] = { 119, 112, 97, 85, 100, 67, 62, 57, 53, 48, 0 };
int bleft_dat[] = { 112, 97, 85, 77, 69, 63, 57, 53, 49, 46, 0 };
int fleft_dat[] = { 124, 108, 95, 83, 75, 67, 63, 57, 54, 50, 0 };
int front_dat[] =
  { 133, 113, 109, 102, 96, 90, 86, 82, 79, 75, 73, 70, 67, 65, 62, 61, 59,
0 };

int side_dist[] = { 60, 70, 80, 90, 100, 110, 120, 130, 140, 150, 160 };
int front_dist[] =
  { -10, 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120, 130, 140, 150,
160 };

/* Sensor averages */
int ir_fright;
int ir_bright;
int ir_right;
int ir_bleft;
int ir_fleft;
int ir_left;
int ir_forward;
int ir_blockd;
int blockd_hold;

int ir_front_raw;
int ir_right_raw;
int ir_left_raw;

int leftwheel, rightwheel, frontwheel;	/* Encoder wheel counts. */

/* Straighten functions */
void straighten_right ();
void straighten_left ();
void strafe_right ();
void strafe_left ();
int lin_interp (int *, int *, int);

void align_forward (int);
void align_backward (int);

/* Robot movement. If > 0, move wheel forward. If < 0 move wheel
   backward. Move until both wheels reach count. */
void robot_move (int left, int right, int counts)
{
  int *leftreg, *rightreg;
  double isum = 0;		/* Integral sum */
  int baseval = 0x1194;		/* 1.5ms */
  int rightoff;			/* Right wheel offset */
  int dist_pgain = 2;
  double dist_igain = 5e-2;
  double tconst = 30;
  int diff_pgain = 60;

  if (counts == 0)
    return;

  if (counts < 15)
    {
      dist_pgain *= 5;
      dist_igain *= 5;
      //diff_pgain *= 15;
    }

  if (left != right)		/* a turn */
    {
      diff_pgain = 10;
    }

  /* Point to registers */
  leftreg = (int *) (&PWMDTY0);
  rightreg = (int *) (&PWMDTY4);

  /* Reset wheel counters */
  leftwheel = 0;
  rightwheel = 0;

  /* Turn on motors */
  PWME = 0x22;

  /* Wait for wheels to finish */
  while (rightwheel < counts)
    {
      int leftoff, differr, disterr;
      differr = rightwheel - leftwheel;
      disterr = counts - rightwheel;

      /* Distance */
      isum = isum + disterr / tconst;
      rightoff = (int) (isum * dist_igain) + disterr * dist_pgain;

      /* Difference */
      leftoff = rightoff + differr * diff_pgain;

      *leftreg = baseval + left * leftoff;
      *rightreg = baseval - right * rightoff;
    }

  /* Turn off motors */
  if (counts < 5 && right != left)
    {
      *leftreg = baseval;
      *rightreg = baseval;
      delay (5);
    }
  PWME = 0x00;
  //delay (5);
}

/* IR reader */
void irr ()
{
  int i;
  int fright_new, bright_new, bleft_new, fleft_new, front_new, blockd_new;
  float a;
  a = 0.85;

  //front_new = (int) ATD0DR0H;
  front_new = lin_interp (front_dist, front_dat, (int) ATD0DR0H);
  fright_new = lin_interp (side_dist, fright_dat, (int) ATD0DR1H);
  bright_new = lin_interp (side_dist, bright_dat, (int) ATD0DR2H);
  bleft_new = lin_interp (side_dist, bleft_dat, (int) ATD0DR4H);
  fleft_new = lin_interp (side_dist, fleft_dat, (int) ATD0DR5H);
  blockd_new = ATD0DR6H;

  ir_forward = a * front_new + (1 - a) * ir_forward;
  ir_fright = a * fright_new + (1 - a) * ir_fright;
  ir_bright = a * bright_new + (1 - a) * ir_bright;
  ir_fleft = a * fleft_new + (1 - a) * ir_fleft;
  ir_bleft = a * bleft_new + (1 - a) * ir_bleft;
  ir_blockd = a * blockd_new + (1 - a) * ir_blockd;

  ir_front_raw = a * ATD0DR0H + (1 - a) * ir_front_raw;
  ir_right_raw = a * ATD0DR1H + (1 - a) * ir_right_raw;
  ir_left_raw = a * ATD0DR5H + (1 - a) * ir_left_raw;

  ir_left = (ir_fleft + ir_bleft) / 2;
  ir_right = (ir_fright + ir_bright) / 2;
}

void correct_sideways ()
{
  int thresh, dist, maxdist;
  thresh = 8;
  dist = 87;
  maxdist = 130;

  irr ();
  if (abs (ir_right - dist) > thresh && (ir_right < maxdist))
    {
      strafe_right ();
      straighten ();
    }
  else if ((ir_right >= 100) && (ir_left < maxdist))
    {
      irr ();
      if (abs (ir_left - dist) > thresh)
	strafe_left ();
    }

  straighten ();
}

/* Line robot up with the wall */
void straighten ()
{
  int dthresh = 150;
  int diffthresh = 120;

  irr ();
  if ((ir_right < dthresh) && (ir_bright < diffthresh)
      && (ir_fright < diffthresh))
    {
      straighten_side (&ir_fright, &ir_bright);
    }
  else if ((ir_left < dthresh) && (ir_bleft < diffthresh)
	   && (ir_fleft < diffthresh))
    {
      straighten_side (&ir_bleft, &ir_fleft);
    }
}

void straighten_side (int *front, int *back)
{
  int thresh = 2;
  int pgain = 5;
  double igain = 1;
  double isum;
  int tconst = 30;
  int *leftreg, *rightreg;
  int baseval = 0x1194;
  int c = 0;

  /* Point to registers */
  leftreg = (int *) (&PWMDTY0);
  rightreg = (int *) (&PWMDTY4);

  *leftreg = baseval;
  *rightreg = baseval;

  irr ();
  PWME = 0x22;
  while (abs (*front - *back) > thresh)
    {
      int offset, err;

      /* Give up after awhile */
      c++;
      if (c > 500)
	{
	  break;
	}

      irr ();
      err = *front - *back;

      isum = isum + (err * 1.0) / tconst;

      offset = err * pgain + isum * igain;
      *leftreg = baseval + offset;
      *rightreg = baseval + offset;
    }
  PWME = 0x00;
}

void strafe_left ()
{
  robot_move (-1, 1, 32);
  align_front ();
  robot_move (1, -1, 32);
}

void strafe_right ()
{
  robot_move (1, -1, 32);
  align_front ();
  robot_move (-1, 1, 32);
}

void align_front ()
{
  int d = 40, thresh = 2;
  int dist_pgain = 3;
  int diff_pgain = 15;
  double dist_igain = 1;
  double isum = 0;
  int tconst = 30;
  int *leftreg, *rightreg;
  int baseval = 0x1194;

  irr ();
  irr ();
  if (ir_forward > 120 || abs (ir_forward - d) <= thresh)
    return;

  /* Point to registers */
  leftreg = (int *) (&PWMDTY0);
  rightreg = (int *) (&PWMDTY4);

  *leftreg = baseval;
  *rightreg = baseval;

  /* Reset wheel counter */
  leftwheel = 0;
  rightwheel = 0;

  /* Turn on motors */
  irr ();
  PTP = 0x80;
  PWME = 0x22;
  while (abs (ir_forward - d) > thresh)
    {
      int diff_err, err, offset, left_offset;

      irr ();
      err = ir_forward - d;
      diff_err = rightwheel - leftwheel;

      isum = isum + err * 1.0 / tconst;

      offset = err * dist_pgain + isum * dist_igain;
      left_offset = offset + diff_pgain * diff_err * isign (offset);
      *leftreg = baseval + left_offset;
      *rightreg = baseval - offset;
    }
  PWME = 0x00;
  PTP = 0x00;
}

int in_maze ()
{
  int scount = 0, fcount = 0, thresh = 4, side = 0;
  int front_t = 33, right_t = 10, left_t = 25;

  irr ();
  if (ir_front_raw < front_t)
    fcount = 1;
  if (ir_right_raw < right_t)
    {
      scount = 1;
      side = 1;
    }
  if (ir_left_raw < left_t)
    {
      scount = 1;
      side = -1;
    }

  if (fcount && scount)
    {
      int i;

      for (i = 1; i <= 5; i++)
	{
	  robot_move (side * 1, side * -1, 3);
	  irr ();
	  if (ir_front_raw >= front_t)
	    {
	      robot_move (side * -1, side * 1, (i - 1) * 3);
	      straighten ();
	      return 1;
	    }
	}

      i -= 2;
      robot_move (side * -1, side * 1, i * 3);
      straighten ();
      return 0;
    }

  return 1;
}

int lin_interp (int *dist, int *dat, int voltage)
{
  int c = 0;

  if (voltage == 0)
    return 160;

  while (voltage <= dat[c])
    c++;

  return (dat[c - 1] - voltage * 1.0) / (dat[c] - dat[c - 1])
    * (dist[c - 1] - dist[c]) + dist[c - 1];
}

void line_forward (int mode)
{
  int d = 39;
  int dist_pgain = 6;
  int diff_pgain = 40;
  int line_pgain = 45;
  double line_igain = 2.5;
  double dist_igain = 0.2;
  double isum = 0;
  double line_isum = 0;
  int tconst = 30;
  int *leftreg, *rightreg;
  int baseval = 0x1194;
  int left_flag = 0;

  /* Point to registers */
  leftreg = (int *) (&PWMDTY0);
  rightreg = (int *) (&PWMDTY4);

  *leftreg = baseval;
  *rightreg = baseval;

  /* Reset wheel counter */
  leftwheel = 0;
  rightwheel = 0;

  /* Turn on motors */
  irr ();
  PWME = 0x22;
  while (rightwheel < d)
    {
      int line_err, diff_err, dist_err, offset, left_offset, line_offset;

      dist_err = d - rightwheel;
      diff_err = rightwheel - leftwheel;
      line_err =
	(((PTH & 32) != 0) - ((PTH & 8) != 0)) * (((PTH & 16) == 0) + 1);
      diff_err = rightwheel - leftwheel;

      isum = isum + dist_err * 1.0 / tconst;
      line_isum = line_isum + line_err * 1.0 / tconst;

      line_offset = line_err * line_pgain + line_igain * line_isum;
      offset = dist_err * dist_pgain + isum * dist_igain;
      left_offset = offset + diff_pgain * diff_err + line_offset;
      *leftreg = baseval + left_offset;
      *rightreg = baseval - offset;

      /* Veer left in bottom red box */
      //if (!left_flag && ((PTH & 32) == 0) && ((PTH & 8) == 0) && ((PTH & 16) == 0))
      //   {
      //   leftwheel += 3;
      //   left_flag = 1;
      // }

      if (((rightwheel > 10) || mode) && (PTH & 0x38) == 0x38)
	break;

      if (block_found ())
	{
	  *leftreg = baseval;
	  *rightreg = baseval;
	  delay (5);
	  PWME = 0x00;
	  num_blocks++;
	  block_pickup ();
	  PWME = 0x22;
	}
    }
  *leftreg = baseval;
  *rightreg = baseval;
  PWME = 0x00;
}

void line_follow ()
{
  int dir = 1, row = 0, i, skipstraight = 1;
  int left_bias = 2;		/* Counter-balance right-bias from motors */

  /* Catch the grid */
  delay (15);
  robot_move (-1, -1, 5);
  delay (15);
  go_to_line ();
  robot_move (-1, 1, 32 + left_bias);
  delay (15);
  robot_move (-1, -1, 10);
  //robot_move (-1, 1, left_bias); /* Hack correction specific to motors! */
  delay (15);
  line_forward (1);

  while (num_blocks < 3)
    {
      row++;

      while ((!wall_forward ()) && (num_blocks < 3))
	{
	  line_forward (0);
	  if (!skipstraight)
	    {
	      straighten ();
	    }
	  else
	    skipstraight = 0;
	}
      if (num_blocks >= 3)
	break;

      if (row >= 6)
	break;

      robot_move (dir, -1 * dir, 32);
      straighten ();

      line_forward (0);
      straighten ();

      robot_move (dir, -1 * dir, 32);
      straighten ();

      dir = dir * -1;
    }

  /* go to 30 from open area */
  if (num_blocks >= 3)
    {
      if (row < 6)
	{
	  robot_move (dir, -1 * dir, 32);
	  while (!wall_forward ())
	    line_forward (0);
	  robot_move (1, -1, 32);
	  straighten ();
	}
      while (!wall_forward ())
	{
	  line_forward (0);
	  straighten ();
	}

      align_front ();
      correct_sideways ();
      turn_right ();
      correct_sideways ();
      go_forward ();
      correct_sideways ();
      go_forward ();
      correct_sideways ();
      go_forward ();
      correct_sideways ();
      turn_right ();
      return;
    }

  robot_move (1, -1, 32);
  straighten ();

  /* Move along left edge */
  for (i = 0; i < 5; i++)
    {
      line_forward (0);
      straighten ();
    }

  robot_move (1, -1, 32);
  straighten ();

  /* Check along maze edge */
  while ((!wall_forward ()) && (num_blocks < 3))
    {
      line_forward (0);
      straighten ();
    }

  /* Go to 30 */
  robot_move (1, -1, 32);
  straighten ();
  robot_move (1, -1, 32);
  straighten ();
  while (!wall_forward ())
    {
      line_forward (0);
      straighten ();
    }
  correct_sideways ();
  robot_move (1, -1, 32);
  correct_sideways ();
  robot_move (1, -1, 32);
  correct_sideways ();
}

void go_to_line ()
{
  int pgain = 15;
  int *leftreg, *rightreg;
  int baseval = 0x1194;
  int offset = 100;

  /* Point to registers */
  leftreg = (int *) (&PWMDTY0);
  rightreg = (int *) (&PWMDTY4);

  *leftreg = baseval;
  *rightreg = baseval;

  /* Reset wheel counter */
  leftwheel = 0;
  rightwheel = 0;

  /* Turn on motors */
  irr ();
  PWME = 0x22;
  while ((PTH & 0x38) != 0x38)
    {
      int err, left_offset;

      irr ();
      err = rightwheel - leftwheel;

      left_offset = err * pgain;
      *leftreg = baseval + offset + left_offset;
      *rightreg = baseval - offset;

    }
  PWME = 0x00;
}

int block_found ()
{
  int thresh = 25;
  float a = 0.85;

  ir_blockd = a * ATD0DR6H + (1 - a) * ir_blockd;

  if (abs (ir_blockd - blockd_hold) > thresh)
    return 1;
  return 0;
}

void block_pickup ()
{
  int oldright, oldleft;
  int segturn = 6;
  int backdist = 3;
  int searchdist = 14;

  /* Remember old values */
  oldright = rightwheel;
  oldleft = leftwheel;

  /* First block */
  PTP = 0x80;
  if (num_blocks == 1)
    {
      /* Back up */
      robot_move (-1, -1, backdist);

      front_turn (segturn, -1);

      /* Rotate */
      robot_move (1, -1, searchdist / 2);
      robot_move (-1, 1, searchdist);
      robot_move (1, -1, searchdist / 2);

      front_turn (segturn * 3, -1);
    }
  else if (num_blocks == 2)
    {
      int cleardist = 8;

      /* Back up */
      robot_move (-1, -1, cleardist + backdist);

      front_turn (segturn * 2, 1);

      robot_move (1, 1, cleardist);

      /* Rotate */
      robot_move (1, -1, searchdist / 2);
      robot_move (-1, 1, searchdist);
      robot_move (1, -1, searchdist / 2);

      front_turn (segturn * 2, -1);
    }
  else if (num_blocks == 3)
    {
      /* Back up */
      robot_move (-1, -1, backdist);

      front_turn (segturn, 1);

      /* Rotate */
      robot_move (1, -1, searchdist / 2);
      robot_move (-1, 1, searchdist);
      robot_move (1, -1, searchdist / 2);

      front_turn (segturn, 1);
    }

  PTP = 0x00;

  rightwheel = oldright;
  leftwheel = oldleft;
}

void front_turn (int counts, int dir)
{
  int *frontreg;
  int baseval = 0x11D0;		/* 1.5ms */
  int rightoff;			/* offset */
  int base_dist_pgain = 15;
  int dist_pgain;

  /* Point to registers */
  frontreg = (int *) (&PWMDTY2);

  /* Reset wheel counters */
  frontwheel = 0;

  /* Turn on motors */
  PWME = 0x08;

  /* Wait for wheels to finish */
  while (frontwheel < counts)
    {
      int disterr;
      disterr = counts - frontwheel;

      /* Change gain based on error */
      if (disterr <= 6)
	dist_pgain = base_dist_pgain * 3;
      else
	dist_pgain = base_dist_pgain;

      /* Distance */
      rightoff = disterr * dist_pgain;

      *frontreg = baseval + rightoff * dir;
    }

  /* Turn off motors */
  PWME = 0x00;
  delay (5);
}
