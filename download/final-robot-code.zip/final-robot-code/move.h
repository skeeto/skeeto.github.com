#ifndef MOVE_H
#define MOVE_H

/* Basic movement */
void turn_right ();
void turn_left ();
void go_forward ();
int wall_forward ();
int wall_right ();
int wall_left ();

#endif
