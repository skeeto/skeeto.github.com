#include "prim_func.h"
#include "move.h"

int wall_forward ()
{
  int thresh = 120;

  irr ();
  if (ir_forward < thresh)
    return 1;
  else
    return 0;
}

int wall_right ()
{
  int thresh = 150;

  irr ();
  if (ir_right < thresh)
    return 1;
  else
    return 0;
}

int wall_left ()
{
  int thresh = 150;

  irr ();
  if (ir_left < thresh)
    return 1;
  else
    return 0;
}

void go_forward ()
{
  robot_move (1, 1, 62);
  align_front ();
  correct_sideways ();
}

void turn_right ()
{
  robot_move (1, -1, 32);
  align_front ();
  straighten ();
}

void turn_left ()
{
  robot_move (-1, 1, 32);
  align_front ();
  straighten ();
}
