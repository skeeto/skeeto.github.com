#ifndef BOT_SETUP_H
#define BOT_SETUP_H

#include <hcs12dp256.h>

/* Intialization functions */
void setup_pwm ();
void setup_porth ();
void setup_atd ();
void setup_led ();

extern int num_blocks;

#endif
