#ifndef PRIM_MOVE_H
#define PRIM_MOVE_H

#include <hcs12dp256.h>

/* Primitive functions */
void robot_move (int left, int right, int counts);
void irr ();
void correct_sideways ();
void straighten ();
void align_front ();
int in_maze ();
int block_found ();

/* Sensor averages */
extern int ir_forward;
extern int ir_fright;
extern int ir_bright;
extern int ir_right;
extern int ir_bleft;
extern int ir_fleft;
extern int ir_left;
extern int ir_blockd;
extern int blockd_hold;

extern int ir_right_raw;
extern int ir_left_raw;
extern int ir_front_raw;

extern int leftwheel, rightwheel, frontwheel;	/* Encoder wheel counts. */

#endif
