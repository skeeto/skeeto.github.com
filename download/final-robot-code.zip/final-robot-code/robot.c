#include <hcs12dp256.h>
#include "move.h"
#include "prim_func.h"

#define NULL 0

typedef struct pos
{
  int x;
  int y;
} pos;

pos *stack = NULL;
pos stack_base[40];
int stack_len = 0;

int bot_map[20][20];

void push_stack (pos p);
pos pop_stack ();
int in_stack (pos p);
int map_marked (pos p);

void rot_right_bot (int *, int *);	/* Rotate direction right */
void rot_left_bot (int *, int *);	/* Rotate direction left */

void robot (pos * repo, pos * start, int vx_init, int vy_init)
{
  int first_move = 1;
  int vx_left, vy_left;
  int i, j;
  int new_vx, new_vy;
  int vx = 0, vy = 1;		/* Assume down */
  pos cur, new;
  int find_repo = 0;

  if (repo != NULL)
    find_repo = 1;

  stack = stack_base;

  for (i = 0; i < 20; i++)
    for (j = 0; j < 20; j++)
      bot_map[i][j] = 0;

  /* Assume being in the middle of a larger map. */
  cur.x = 10;
  cur.y = 10;

  if (find_repo)
    {
      int bvx, bvy, i;		/* behind direction */
      pos bpos;

      /* Given start */
      cur.x = start->x;
      cur.y = start->y;
      vx = vx_init;
      vy = vy_init;

      /* Mark and push behind onto stack */
      bvx = vx;
      bvy = vy;
      rot_right_bot (&bvx, &bvy);
      rot_right_bot (&bvx, &bvy);
      bpos.x = cur.x + bvx;
      bpos.y = cur.y + bvy;

      bot_map[cur.x + bvx][cur.y + bvy] = 1;
      push_stack (bpos);

      for (i = 0; i < 20; i++)
	{
	  bot_map[i][cur.y + 2 * bvy] = 1;
	}
    }

  bot_map[cur.x][cur.y] = 1;

  while (first_move || find_repo || in_maze ())
    {
      pos forward, right, left;
      int vx_right, vy_right;
      int vx_left, vy_left;
      forward.x = cur.x + vx;
      forward.y = cur.y + vy;

      first_move = 0;

      vx_right = vx;
      vy_right = vy;
      rot_right_bot (&vx_right, &vy_right);
      right.x = cur.x + vx_right;
      right.y = cur.y + vy_right;

      vx_left = vx;
      vy_left = vy;
      rot_left_bot (&vx_left, &vy_left);
      left.x = cur.x + vx_left;
      left.y = cur.y + vy_left;

      /* Stop if at the repository */
      if (find_repo)
	{
	  if (cur.x == repo->x && cur.y == repo->y)
	    return;
	}

      if (!wall_right () && !map_marked (right))
	{
	  turn_right ();
	  rot_right_bot (&vx, &vy);
	  go_forward ();
	  push_stack (cur);
	  cur = right;
	}
      else if (!wall_left () && !map_marked (left))
	{
	  turn_left ();
	  rot_left_bot (&vx, &vy);
	  go_forward ();
	  push_stack (cur);
	  cur = left;
	}
      else if (!wall_forward () && !map_marked (forward))
	{
	  go_forward ();
	  push_stack (cur);
	  cur = forward;
	}
      else
	{
	  new = pop_stack ();
	  new_vx = new.x - cur.x;
	  new_vy = new.y - cur.y;

	  while (!(vx == new_vx && vy == new_vy))
	    {
	      turn_right ();
	      straighten ();
	      rot_right_bot (&vx, &vy);
	    }

	  go_forward ();
	  cur = new;
	}

      bot_map[cur.x][cur.y] = 1;
    }				/* Main loop */
}

void push_stack (pos p)
{
  *stack = p;
  stack++;
}

pos pop_stack ()
{
  stack--;
  return *stack;
}

int in_stack (pos p)
{
  pos *i;
  for (i = stack_base; i < stack; i++)
    {
      if (i->x == p.x && i->y == p.y)
	{
	  return 1;
	}
    }
  return 0;
}

void rot_left_bot (int *vx, int *vy)
{
  int swap;
  swap = *vx;
  *vx = *vy;
  *vy = swap;

  if (*vx != 0)
    {
      *vx = *vx * -1;
      *vy = *vy * -1;
    }
}

void rot_right_bot (int *vx, int *vy)
{
  int swap;
  swap = *vx;
  *vx = *vy;
  *vy = swap;

  if (*vy != 0)
    {
      *vx *= -1;
      *vy *= -1;
    }
}

int map_marked (pos p)
{
  return bot_map[p.x][p.y];
}

void go_to_repo ()
{
  pos repo, start;

  int x = 0;
  /* Starting from 30 */
  while (wall_left ())
    {
      x++;
      go_forward ();
      correct_sideways ();
    }
  turn_left ();
  go_forward ();

  /* We are now in front of opening. */
  start.x = x;
  start.y = 4;
  repo.x = 2;
  repo.y = 6;
  robot (&repo, &start, 0, 1);
}
