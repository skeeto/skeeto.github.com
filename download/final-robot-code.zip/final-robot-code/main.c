#include <hcs12dp256.h>

#include "setup.h"
#include "prim_func.h"
#include "move.h"

void delay (int);

int start_button;		/* Start button pushed? */

int main ()
{
  /* Set up hardware */
  setup_porth ();
  setup_atd ();
  setup_pwm ();
  setup_led ();

  /* Initialize IR sensors */
  delay (10);
  ir_blockd = ATD0DR6H;
  irr ();
  delay (10);
  irr ();
  blockd_hold = ir_blockd;
  delay (10);

  /* Wait for start button */
  PTP = 0x80;
  start_button = 0;
  while (!start_button)
    delay (10);
  PTP = 0x00;
  delay (75);

  /* Set up front wheel */
  front_turn (6, 1);

  correct_sideways ();
  while (wall_forward ())
    turn_right ();

  /* Escape the maze */
  robot (0, 0, 0, 0);

  /* Follow lines */
  correct_sideways ();
  line_follow ();

  /* At this point, robot should at 30 be facing along maze */
  go_to_repo ();

  /* Program complete. Do nothing */
  PTP = 0x80;
  while (1)
    delay (10);

  return 0;
}

/**********************************************************************/
/* Short delay. delay (50) is about 1 second. */
void delay (int t)
{
  int i, j;

  for (i = 0; i < t; i++)
    for (j = 0; j < 32000; j++)
      {
      }
}

/**********************************************************************/
/* Simple absolute value */
int abs (int x)
{
  if (x < 0)
    x *= -1;
  return x;
}

/**********************************************************************/
/* Simple sign value */
int isign (int x)
{
  if (x < 0)
    return -1;
  else if (x > 0)
    return 1;
  else
    return 0;
}

/**********************************************************************/
/* Interrupt Service Routine
 * preconditions:
 *   port H initialized before enabling interrupts
 *   interrupts enabled
 */

/* This pragma tells ICC12 to include an RTI instruction at the end */
#pragma interrupt_handler encoder_isr

void encoder_isr ()
{
  if (PIFH & 1)
    {
      leftwheel++;
    }
  if (PIFH & 2)
    {
      rightwheel++;
    }
  if (PIFH & 0x40)
    {
      frontwheel++;
    }
  if (!start_button && PIFH & 4)
    {
      delay (10);		/* Switch bounce */
      start_button = 1;
    }

  /* Clear flag, otherwise ISR will keep responding to same
     interrupt. */
  PIFH = PIFH | 1;
}
