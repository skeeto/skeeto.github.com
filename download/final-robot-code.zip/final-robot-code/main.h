#ifndef ROBOT_MAIN_H
#define ROBOT_MAIN_H

void delay (int);
int abs (int);
int isign (int);

#endif
