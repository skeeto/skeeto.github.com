#include "setup.h"

int num_blocks = 0;

void setup_porth ()
{
  /* Configure port H for interrupts on channel 0; push button */
  DDRH = 0x80;			// configure channel 0-6 as input
  PPSH = 0x43;			// channels 0,1,6 responds to rising edge
  PIEH = 0x47;			// Enable interrupts on channel 0,1,2,6
  PIFH = 0xFF;			// clear all flags
  INTR_ON ();			// enable interrupts
}

void setup_pwm ()
{
  /* SA and SB setup */
  PWMSCLA = 0x02;		//SA SB clock
  PWMSCLB = 0x02;		//SA SB clock
  PWMPRCLK = 0x11;		//prescalar

  /* Set up PWM1 (left wheel) */
  PWMPOL = 0x02;		//polarity
  PWMPER0 = 0xEA;		//period
  PWMPER1 = 0x60;		//period
  PWMCLK = 0x02;		//clock select
  PWMCTL = 0x10;
  PWMDTY0 = 0x11;		// 1.5 ms - neutral
  PWMDTY1 = 0x94;		//

  /* Set up PWM5 (right wheel) */
  PWMPOL = PWMPOL | 0x20;	//polarity
  PWMPER4 = 0xEA;		//period
  PWMPER5 = 0x60;		//period
  PWMCLK = PWMCLK | 0x20;	//clock select
  PWMCTL = PWMCTL | 0x40;
  PWMDTY4 = 0x11;		// 1.5 ms - neutral
  PWMDTY5 = 0x94;		//

  /* Set up PWM3 (front wheel) */
  PWMPOL = PWMPOL | 0x08;	//polarity
  PWMPER2 = 0xEA;		//period
  PWMPER3 = 0x60;		//period
  PWMCLK = PWMCLK | 0x08;	//clock select
  PWMCTL = PWMCTL | 0x20;
  PWMDTY2 = 0x11;		// 1.5 ms - neutral
  PWMDTY3 = 0x94;		//  
}

void setup_atd ()
{
  /* Analog to Digital converter setup */
  ATD0CTL5 = 0x30;		// Scan mode, multiple channels
  ATD0CTL4 = 0xCB;		// 8-bit, long sample time
  ATD0CTL3 = 0x38;		// Conversion sequence length (7 channels)
  ATD0CTL2 = 0x80;		// enables (bit 7 is 1)
}

void setup_led ()
{
  /* Set up LED */
  DDRP = 0x80;
}
