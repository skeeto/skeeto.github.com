/* nncommon.cpp - Neural Network class
 * Copyright (C) 2007 Christopher Wellons <ccw129@psu.edu>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301, USA.
 */ 

#include <math.h>
#include <sstream>
#include <iostream>
#include "nncommon.h"
using namespace std;

/*------------------------------------------------------------------*/
double sumSqErr(double dout[], double rout[], int size)
{
  double sum = 0;
  for (int i = 0; i < size; i++)
    {
      sum += pow(dout[i] - rout[i], 2.0);
    }
  
  return sum;
}

/*------------------------------------------------------------------*/
int roundit(double x)
{
  if ( x > .5 )
    return 1;
  return 0;
}

/*------------------------------------------------------------------*/
void int2double(int iarr[], double darr[], 
		int numint, int bits_per_int)
{
  int curint;
  
  for (int i = 0; i < numint; i++)
    {
      // Don't damage the given array so we copy the current work
      curint = iarr[i];
      for (int j = bits_per_int - 1; j >= 0; j--)
	{
	  if (curint % 2 == 0)
	    darr[j + bits_per_int * i] = 0;
	  else
	    darr[j + bits_per_int * i] = 1;
	  curint /= 2;
	}
    }
}

/*------------------------------------------------------------------*/
int double2int(double darr[], int bits)
{
  int sum = 0;
  int bit;
  for (int i = 0; i < bits; i++)
    {
      bit = roundit(darr[i]);
      if (bit == 1)
	  sum += (int)pow(2.0, bits - i - 1);
    }
  
  return sum;
}

/*------------------------------------------------------------------*/
void print_double(double darr[], int size)
{
  int i;
  for (i = 0; i < size - 1; i++)
    {
      cout << darr[i] << ", ";
    }
  cout << darr[i];
}
