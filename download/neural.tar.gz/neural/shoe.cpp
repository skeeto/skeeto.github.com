/* shoe.cpp - Blackjack Neural Network
 * Copyright (C) 2007 Christopher Wellons <ccw129@psu.edu>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301, USA.
 */ 

#include "shoe.h"
using namespace std;

shoe::shoe()
{
  // Make a single deck
  generate_deck();
}

shoe::shoe(int n)
{
  // Make multiple decks
  for (int i = 0; i < n; i++)
    generate_deck();
}

void shoe::generate_deck()
{
  // Generate the deck
  for (int j = 0; j < 4; j++)
    {
      discard_deck.push_back(1); // ace
      for (int i = 2; i < 11; i++)
	{
	  discard_deck.push_back(i); // 2-10
	}
      discard_deck.push_back(10); // jack
      discard_deck.push_back(10); // queen
      discard_deck.push_back(10); // king
    }
  
  replace();
}

int shoe::deal()
{
  int topcard = deck.back();
  deck.pop_back();
  
  if (deck.empty())
    {
      replace();
    }
  
  return topcard;
}

int shoe::peek()
{
  int topcard = deck.back();
  return topcard;
}

void shoe::discard(vector<int> &in)
{
  while (!in.empty())
    {
      discard_deck.push_back(in.back());
      in.pop_back();
    }
}

void shoe::replace()
{
  // First shuffle, then return to the deck
  unsigned int size = discard_deck.size();
  unsigned int temp, pos;
  for (unsigned int i = 0; i < size; i++)
    {
      // Choose a card to swap with
      pos = ( rand() % (size - i) ) + i;

      // Swap these two
      temp = discard_deck[i];
      discard_deck[i] = discard_deck[pos];
      discard_deck[pos] = temp;
    }
  
  // Put it back in the deck
  while (!discard_deck.empty())
    {
      deck.push_back(discard_deck.back());
      discard_deck.pop_back();
    }
}
