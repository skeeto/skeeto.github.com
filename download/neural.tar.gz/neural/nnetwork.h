/* nnetwork.h - Neural Network class
 * Copyright (C) 2007 Christopher Wellons <ccw129@psu.edu>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301, USA.
 */ 

/* This is a neural network implimenting back-propagation with use of
 * the sigmoid function activation in the neurons. The network accepts
 * an array of doubles and returns an array of doubles. Each double in
 * the array should be between 0 and 1. The class has three important
 * methods:
 *
 * run 
 *  Provide the input and the neural network is activated and a return
 *  value is generated.
 *
 * train
 *   Give an input and the desired output and the network will
 *   perform exactly one training iteration (one back-propagation).
 *
 * save (and load using constructor)
 *   Load and save the current state of the network.
 *
 * The output is a pointer to a double array containing the actual
 * output. Note that this array will be overridden when the network is
 * run again. Use the array or copy it before running the network
 * again.
 *
 * Look at the constructor to see how to create a neural network.
 *
 */

#ifndef NNETWORK_H
#define NNETWORK_H

#include "layers.h"
using namespace std;

class NNetwork 
{
public:
  NNetwork(int numinputs, int numoutputs, 
	   int numlayers, int numneurons, double learnrate);

  ~NNetwork();

  // Load a neural network from a file. There is no error checking so
  // make sure you give it a valid file to load! If not, who knows
  // what may happen?
  NNetwork(char filename[]);

  // Run the network
  double* run(double[]);
  
  // Run the network but also train it based on the desired output
  double* train(double[], double[]);
  
  // Return the output pointer
  double* getOutput();
  
  // Network attributes
  int numin;
  int numout;
  
  // Network outputs
  double *outputs;

  // Save the neural network to a file
  void save(char filename[]);

private:
  // Array of layers
  HLayer **layers;
  int nlayers;

  // Input and output layers
  ILayer *ilayer;
  HLayer *olayer;
  
  // Learning rate for the network
  double lrate;
};

#endif
