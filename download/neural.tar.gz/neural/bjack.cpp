/* bjack.cpp - Blackjack Neural Network
 * Copyright (C) 2007 Christopher Wellons <ccw129@psu.edu>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301, USA.
 */ 

/* This neural network is trained to play blackjack. After training,
 * you can then play blackjack against the neural network. The neural
 * network is not trained to any strategy, but develops its own.
 *
 * Training works by peeking ahead in the deck (cheating). The neural
 * network is given a hand and the opponent's up card. It makes a
 * single play (hit or stand). The "teacher," who has peeked ahead in
 * the deck and knows the best play that can be made, then tells the
 * neural network what play should have played based on this extra
 * information. To give the neural network a good opponent to learn
 * to, the opponent gets to cheat as well.
 *
 * The blackjack simulator in which the network is trained behaves the
 * same way a real deck (or decks) of cards would in a real blackjack
 * game with a shoe. Cards are put into a discard pile after use,
 * which is later shuffled and placed back into the dealing deck.
 *
 * Again, the neural network was not given a strategy, just told what
 * was the optimal move given the situation it had. It forms its own
 * rules and strategies which are unknown.
 *
 * After training is complete, the player can then play against the
 * computer in blackjack. Because the user is the second opponent
 * (acting as a psuedo-dealer), the computer is at a disadvantage in
 * this situation.
 */

#include <iostream>
#include <ctime>
#include <fstream>
#include "nnetwork.h"
#include "nncommon.h"
#include "shoe.h"
#include "hand.h"
using namespace std;

int    layers   = 2;
int    neurons  = 15;
double lrate    = 0.01;
int    loops    = 1000000;
int    checkint = 10000;
double thresh   = 83;

int    numin    = 15; // player value, player min, and dealer (5 each)
int    numout   = 1;  // 2 possible plays: hit, stand

void play_bjack(NNetwork&);     // Play blackjack with given network
int  calc_winner(int a, int b); // Calculate winner given scores
void train_bjack(NNetwork &);   // Train the neural network

int main()
{
  // set the random generator seed
  srand((unsigned)time(0));
  
  // Create a random neural network
  cout << "Creating network ... ";
  NNetwork nn(numin, numout, layers, neurons, lrate);
  cout << "created!" << endl;

  // Train the network
  train_bjack(nn);
  
  // Save the brain in case we want it later
  nn.save("bjack_brain.txt");
  
  // Now play blackjack with the neural network
  play_bjack(nn);
  
  return 0;
}

void train_bjack(NNetwork &nn)
{
  // allocate input/output memory
  int    *intin  = new int[3];
  double *in     = new double[numin];
  double *out    = new double[numout];
  double *output = nn.getOutput();
  
  // create a shoe, dealer, and player hands
  shoe deck;
  hand dealer;
  hand player;
  int dealer_up;
  
  // counters
  int won = 0, lost = 0, correct = 0, wrong = 0;
  int lastwon = 0, lastlost = 0, lastcorrect = 0, lastwrong = 0;
  double wonp = 0, corp = 0; // Win and correct percentages
  
  // file to dump training progress
  ofstream winfile, errfile;
  winfile.open("win.txt");
  errfile.open("err.txt");
  
  // Train the network
  cout << "Training ..." << endl;
  for (int i = 0; i < loops && corp < thresh; i++)
    {
      output[0] = 1;
      player.fold(deck);
      dealer.fold(deck);
      
      // Play until player stands ot busts
      while (player.value() < 21 && output[0] > 0.5)
	{
	  // Deal two cards to player
	  player.take(deck.deal());
	  dealer.take(deck.deal());
	  dealer_up = dealer.value();      
      
	  player.take(deck.deal());
	  dealer.take(deck.deal());
      
	  // Set up the input
	  intin[0] = player.min();
	  intin[1] = player.value();
	  intin[2] = dealer_up;
	  int2double(intin, in, 2, 5);
	  
	  // Cheat to determine optimal play (which may still lose)
	  if (deck.peek() + player.min() <= 21)
	    out[0] = 1; // hit
	  else
	    out[0] = 0; // stand
      
	  // Tell the neural network whats going on
	  nn.train(in, out);
	  
	  // Do what the neural network said:
	  if (output[0] > 0.5)
	      player.take(deck.deal());
	  
	  if (roundit(output[0]) == out[0])
	    correct++;
	  else
	    wrong++;
	}
      
      // Now see who wins
      if (player.value() > 21)
	lost++;
      else
	{
	  while (dealer.value() != 21
		 && dealer.value() < player.value() 
		 && deck.peek() + dealer.min() <= 21)
	    dealer.take(deck.deal());	    
	  
	  // Winning and losing conditions
	  if (dealer.value() > player.value())
	    lost++;
	  else
	    if (dealer.value() != player.value())
	      won++;
	}
      
      // Output statistics
      if ((i+1) % checkint == 0 && i > 1)
	{
	  wonp = (won-lastwon)*100.0/ checkint;
	  corp = (correct-lastcorrect)*100.0
	    / (correct-lastcorrect+wrong-lastwrong);
	  
	  cout << "Win, lose, total, c%, win%: " 
	       << won << ", " << lost << ", " << i+1 << ", "
	       << corp << "% , " 
	       << wonp << "%" << endl;
	  winfile << wonp << endl;
	  errfile << corp << endl;
	  
	  // Reset interval counters
	  lastwon = won;
	  lastlost = lost;
	  lastcorrect = correct;
	  lastwrong = wrong;
	}
    }
  if (thresh < corp)
    {
      cout << "Learning threshold reached!" << endl;
    }
  
  // Clean up
  winfile.close();
  errfile.close();
}

// Play blackjack with the given neural network
void play_bjack(NNetwork &nn)
{ 
  double *output = nn.getOutput();    // nn output
  int intin[3];                       // nn input (int)
  double *in = new double[numin];     // nn input (double)
  int player_up;                      // Player's up card 
  int won = 0, lost = 0, played = 0;  // statistical info
  char play_again = 'y', hit;         // user input
  int winner;                         // winner of round
  
  // Create two hands and a shoe
  shoe deck;
  hand player;
  hand computer;
  
  while (play_again == 'y')
    {
      cout << endl << "Begin game:" << endl;
      played++;
      
      computer.fold(deck);
      player.fold(deck);

      // Deal
      computer.take(deck.deal());
      player.take(deck.deal());
  
      player_up = player.value();
      
      computer.take(deck.deal());
      player.take(deck.deal());
      
      cout << "Computer is dealt: ";
      computer.display();
      
      output[0] = 1;
      while (computer.value() <= 21 && output[0] > 0.5)
	{
	  // Encode the inputs
	  intin[0] = computer.value();
	  intin[1] = computer.min();
	  intin[2] = player_up;
	  int2double(intin, in, 3, 5);
	  
	  nn.run(in);
	  
	  if (output[0] > 0.5)
	    {
	      computer.take(deck.deal());
	      cout << "Computer is dealt: ";
	      computer.display();
	    }
	  else
	      cout << "Computer stands." << endl;
	}
      
      if (computer.value() > 21)
	{
	  cout << "Computer busts with " << computer.value() << endl;
	}
      

      // Player (user) plays
      hit = 'y';
      while (player.value() <= 21 && hit == 'y')
	{ 
	  // Display hand
	  cout << "Your hand: ";
	  player.print();
	  
	  cout << "Hit? (y/n): ";
	  cin >> hit;
	  if (hit == 'y')
	      player.take(deck.deal());
	}
      // Display last hand
      cout << "Your hand: ";
      player.print();

      if (player.value() > 21)
	cout << "You bust with " << player.value() << endl;
      
      // Calculate the winner
      winner = calc_winner(player.value(), computer.value());
      if (winner > 0)
	  cout << "Computer wins with " << computer.value() 
	       << " against your " << player.value() << endl;
      else if (winner < 0)
	  cout << "You win with " << player.value() 
	       << " against computer's " << computer.value() << endl;
      else
	  cout << "Push with " << player.value() << endl;

      // Add to counter
      won  += winner * (winner + 1) * 1/2;
      lost += winner * (winner - 1) * 1/2;
      
      cout << "Play again? (y/n) : ";
      cin >> play_again;
    }

  // Output statistics
  int pushed;
  pushed = played - won - lost;
  cout << endl   << "Computer wins, losses, push: "
       << won    << " (" << won    * 100.0 / played << "%), "
       << lost   << " (" << lost   * 100.0 / played << "%), "
       << pushed << " (" << pushed * 100.0 / played << "%)"
       << endl;
}

// if the return value is <  0, a won
// if the return value is >  0, b won
// if the return value is == 0, push
int calc_winner(int a, int b)
{
  if (a == b)
    return 0;

  if (a > 21 && b > 21)
    return 0;

  if (a > 21 && b <= 21)
    return 1;
  
  if (a <= 21 && b > 21)
    return -1;
  
  // All values <= 21 here
  if (a < b)
    return 1;
  else
    return -1;
}
