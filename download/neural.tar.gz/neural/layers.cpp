/* layers.cpp - Neural Network class
 * Copyright (C) 2007 Christopher Wellons <ccw129@psu.edu>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301, USA.
 */ 

#include <vector>
#include "neuron.h"
#include "layers.h"
using namespace std;

// Hidden Layer
HLayer::HLayer(int numneurons, double lrate, HLayer *back, 
	       double *weights, double thetas[])
{
  ncount = numneurons;

  neurons = new Neuron*[ncount];
  double *weightp;
  int backsize;
  
  // Create a new node, connect to all of the nodes in the previous
  // layer, repeat ncount times
  for (int i = 0; i < ncount; i++)
    {
      if (thetas != NULL)
	neurons[i] = new Neuron(lrate, thetas[i]);
      else
	neurons[i] = new Neuron(lrate, 0);
	
      if (back != NULL)
	{
	  backsize = back->size();
	  
	  for (int j = 0; j < backsize; j++)
	    {
	      // Connect our nodes
	      weightp = 
		neurons[i]->addBackward((*back)[j], 
					weights[i*backsize+j]);
	      (*back)[j]->addForward(neurons[i], weightp);
	    }
	}
    }
}
  
void HLayer::activate()
{
  // Activate each neuron in the layer
  for (int i = 0; i < ncount; i++)
    {
      neurons[i]->activate();
    }
}

void HLayer::train()
{
  // Train each neuron in the layer
  for (int i = 0; i < ncount; i++)
    {
      neurons[i]->train();
    }  
}

void HLayer::train(double out[])
{
  // Train each neuron in the layer
  for (int i = 0; i < ncount; i++)
    {
      neurons[i]->train(out[i]);
    }  
}

void HLayer::save(ofstream *savefile)
{
  // Save layer header
  *savefile << "LAYER" << endl;
  *savefile << "Neurons: " << ncount << endl;
  
  for (int i = 0; i < ncount; i++)
    {
      neurons[i]->save(savefile);
    }
  
  // close the layer
  *savefile << "ENDLAYER" << endl << endl;
}

int HLayer::size()
{
  return ncount;
}

Neuron* HLayer::operator[](int i)
{
  return neurons[i];
}

HLayer::~HLayer()
{
  delete [] neurons;
}

/*----------------------------------------*/
// Input layer

ILayer::ILayer(int neurons) : HLayer(neurons, 0, NULL, NULL, NULL)
{
}

void ILayer::activate()
{
  // Pass inputs directly to outputs
  for (int i = 0; i < ncount; i++)
    {
      neurons[i]->output = inputs[i];
    }
}

void ILayer::train()
{
  // Do nothing. Input layer needs no training.
}
