/* neuron.cpp - Neural Network class
 * Copyright (C) 2007 Christopher Wellons <ccw129@psu.edu>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301, USA.
 */ 

#include <list>
#include <math.h>
#include <iostream>
#include "neuron.h"
using namespace std;

Neuron::Neuron(double lrate, double theta)
{
  this->lrate = lrate;
  this->theta = theta;
}

void Neuron::addForward(Neuron* node, double *weight)
{
  fnode_t newnode;
  
  newnode.node = node;
  newnode.weight = weight;
  
  forward.push_back(newnode);
}

double* Neuron::addBackward(Neuron* node, double weight)
{
  bnode_t newnode;
  
  newnode.node = node;
  newnode.weight = weight;
  
  backward.push_back(newnode);
  
  // Return a pointer to where we stored this weight
  return &backward.back().weight;
}

void Neuron::activate()
{
  double sum = 0;
  
  // Sum up each input
  list<bnode_t>::iterator i;
  for (i = backward.begin(); i != backward.end(); i++)
    {
      sum += i->node->output * i->weight;
    }
  
  // Subtract threshhold
  sum = sum - theta;
  
  // Sigmoid function
  output = 1/(1 + exp(-sum));
}

void Neuron::train()
{
  double errsum = 0;
  
  // Calculate the sum
  list<fnode_t>::iterator i;
  for (i = forward.begin(); i != forward.end(); i++)
    {
      errsum += i->node->errgrad * *(i->weight);
    }

  // Calculate and set the error gradient
  errgrad = errsum * output * (1 - output);

  updateWeights();
}

void Neuron::train(double dout)
{
  // Simple error gradient calculation
  errgrad = output * (1 - output) * (dout - output);
  
  updateWeights();
}

void Neuron::updateWeights()
{
  // Run the weight calculation on each weight
  list<bnode_t>::iterator i;
  for (i = backward.begin(); i != backward.end(); i++)
    {
       i->weight += lrate * i->node->output * errgrad;
    }
  
  // Update the activation threshold
  theta += lrate * -1 * errgrad;
}

void Neuron::save(ofstream *savefile)
{
  // Only one theta per node
  *savefile << "Theta: " << theta << endl;
  
  // Save each weight
  list<bnode_t>::iterator i;
  for (i = backward.begin(); i != backward.end(); i++)
    {
      *savefile << i->weight << endl;
    }
  *savefile << endl;
}
