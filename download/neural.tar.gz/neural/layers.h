/* layers.h - Neural Network class
 * Copyright (C) 2007 Christopher Wellons <ccw129@psu.edu>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301, USA.
 */ 

#ifndef HLAYER_H
#define HLAYER_H

#include "neuron.h"
#include <fstream>
using namespace std;

// This is the basic hidden layer. It is used for both hidden layers
// and output layers. The input layer class inherits this class.
class HLayer
{
public:
  HLayer(int ncount, double lrate, HLayer *back, 
	 double *weights, double thetas[]);
  ~HLayer();

  // Layer actions
  void activate();
  void train();
  void train(double[]);
  void save(ofstream*);
  
  // Accessing neurons
  int size();
  Neuron* operator[](int);
  
protected:
  // List of neurons and size of the list
  Neuron **neurons;
  int ncount;
};

// Input layer
class ILayer : public HLayer
{
public:
  ILayer(int);
  
  // Overriding the activate and train functions
  void activate();
  void train();
  
  // Set of inputs
  double* inputs;
};

#endif
