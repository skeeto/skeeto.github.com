/* shoe.h - Blackjack Neural Network
 * Copyright (C) 2007 Christopher Wellons <ccw129@psu.edu>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301, USA.
 */ 

/* This shoe is meant to properly simulate a shoe: a full deck which
 * gets shuffled and replaced when the dealing deck is empty.
 */

#ifndef SHOE_H
#define SHOE_H

#include <vector>
using namespace std;

// Shoe class: the deck(s) we deal the cards from
class shoe {
public:
  shoe();    // Use a single deck
  shoe(int); // Use more than 1 deck
  
  // Deal the next card
  int  deal();
  
  // Peak at the next card
  int  peek();
  
  // Add cards to discard_deck
  void discard(vector<int>&);
  
private:
  void generate_deck();
  void replace();
  
  vector<int> deck;
  vector<int> discard_deck;
};

#endif
