/* nncommon.h - Useful functions for use with the Neural Network class
 * Copyright (C) 2007 Christopher Wellons <ccw129@psu.edu>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301, USA.
 */ 

#ifndef NNCOMMON_H
#define NNCOMMON_H

#include <sstream>

// Calculate sum of squared errors of the two double array
double sumSqErr(double dout[], double rout[], int size);

// Rounds the given double to either a 1 or a 0.
int roundit(double);

// Converts an array of integers into an array of doubles as a binary
// representation. The pointer to the double must already be
// allocated.
void int2double(int iarr[], double darr[], 
		int numint, int bits_per_int);

// Convert numbits bits of the given double array into an integer.
int double2int(double darr[], int numbits);

// Print the double array as a comma separated list
void print_double(double darr[], int size);

#endif
