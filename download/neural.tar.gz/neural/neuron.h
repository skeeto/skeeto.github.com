/* neuron.h - Neural Network class
 * Copyright (C) 2007 Christopher Wellons <ccw129@psu.edu>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301, USA.
 * 
 */

/* This is a single neuron for the neural network. It keeps track of
 * connections to neurons in forward layers and connections and
 * weights to neurons in backward layers in the network. The forward
 * weight is stored by pointer to the next layer which maintains the
 * weight. 
 *
 * A list is used here instead of a vector because a vector may be
 * relocated and this messes up the weight pointers. List atoms don't
 * (shouldn't?) move.
 */

#ifndef NEURON_H
#define NEURON_H

#include <list>
#include <fstream>
using namespace std;


class Neuron
{
public:
  Neuron(double lrate, double theta);
  
  // Keep track of nodes in front in the next layer
  typedef struct fnode_t 
  {
    Neuron *node;
    double *weight;
  } fnode_t;
  
  // Keep track of nodes in the last layer
  typedef struct bnode_t 
  {
    Neuron *node;
    double weight;
  } bnode_t;
  
  // Connect neurons together
  void addForward(Neuron*, double *weight);
  double* addBackward(Neuron*, double weight);
  
  // Actions
  void activate();
  void train();
  void train(double outerr);
  void save(ofstream*);
  
  // error gradient
  double errgrad;
  
  // theta
  double theta;

  // neuron output value
  double output;

private:
 
  // learning rate
  double lrate;

  // Keep track of connections
  list<fnode_t> forward;
  list<bnode_t> backward;  
  
  // updates the weights between this node and its backward nodes
  void updateWeights();
};

#endif
