/* nnetwork.cpp - Neural Network class
 * Copyright (C) 2007 Christopher Wellons <ccw129@psu.edu>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301, USA.
 */ 

#include "layers.h"
#include "nnetwork.h"
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

// Fills the given matrix with random values
void rand_matrix(double *mat, int size, double min, double max)
{
  for (int i = 0; i < size; i++)
    {
      mat[i] = rand()*1.0/RAND_MAX * (max - min) + min;
    }
}

NNetwork::NNetwork(int numinputs, int numoutputs, 
		   int numlayers, int numneurons, double learnrate)
{
  // copy the values to the class members
  numout = numoutputs;
  numin = numinputs;
  nlayers = numlayers;
  lrate = learnrate;

  // create the input layer
  ilayer = new ILayer(numinputs);
  
  // Allocate the arrays
  outputs = new double[numoutputs];
  layers = new HLayer*[numlayers];
  
  double *weights;
  double *thetas;
  int backsize;
  
  // Create each layer. The layers will connect themselves
  HLayer *lastlayer = ilayer;
  for (int i = 0; i < numlayers; i++)
    {
      backsize = lastlayer->size();
      
      // Generate random values
      weights = new double[numneurons*backsize];
      thetas  = new double[numneurons];
      rand_matrix(weights, numneurons*backsize, -0.5, 0.5);
      rand_matrix(thetas, numneurons, 2, -2);

      // Create the layer
      layers[i] = new HLayer(numneurons, lrate, lastlayer, 
			     weights, thetas);
      
      // No memory leaks!
      delete [] weights;
      delete [] thetas;
      
      // Point to this layer for the next layer to look at
      lastlayer = layers[i];
    }
  
  // Setup the output layer
  backsize = lastlayer->size();
  weights = new double[numneurons*backsize];
  thetas  = new double[numneurons];
  rand_matrix(weights, numneurons*backsize, -0.5, 0.5);
  rand_matrix(thetas, numneurons, 2, -2);
  
  olayer = new HLayer(numoutputs, lrate, lastlayer, weights, thetas);

  // clean up allocated memory
  delete [] weights;
  delete [] thetas;
}

NNetwork::NNetwork(char filename[])
{
  ifstream loadfile;
  loadfile.open(filename);

  // Read in the intial network information
  string token;
  
  // Inputs:
  loadfile >> token;
  loadfile >> numin;
  
  // Outputs:
  loadfile >> token;
  loadfile >> numout;
  
  // Layers:
  loadfile >> token;
  loadfile >> nlayers;

  // Learning rate:
  loadfile >> token;
  loadfile >> lrate;
  
  // Start building the network
  layers  = new HLayer*[nlayers];
  outputs = new double[numout];
  ilayer  = new ILayer(numin);

  // Used while building the network
  double *weights; // Matrix of weights for the layer
  int numneurons;  // Number of neurons in the layer
  double *theta;   // Theta values of the neurons (array)
  int backsize;    // Number of connection to previous layer

  HLayer *lastlayer = ilayer;
  for (int i = 0; i <= nlayers; i++)
    {
      // Find the number of neurons
      loadfile >> token; // LAYER
      loadfile >> token; // Neurons:
      loadfile >> numneurons;
      
      backsize = lastlayer->size();
      
      // Allocate our arrays
      weights = new double[numneurons * backsize];
      theta = new double[numneurons];
      
      // Load each neuron
      for (int j = 0; j < numneurons; j++)
	{
	  loadfile >> token; // Theta:
	  loadfile >> theta[j];
	  
	  // Read in each weight for this neuron
	  for (int k = 0; k < backsize; k++)
	    {
	      loadfile >> weights[j*backsize+k];
	    }
	}

      // Create the layer
      if (i < nlayers)
	{	
	  layers[i] = new HLayer(numneurons, lrate, lastlayer, 
				 weights, theta);
	}
      else
	{
	  olayer = new HLayer(numneurons, lrate, lastlayer, 
				 weights, theta);	  
	}
      
      // Point to this layer for the next layer
      lastlayer = layers[i];
      
      // Deallocate
      delete [] theta;
      delete [] weights;
      
      loadfile >> token; // ENDLAYER
    }  

  loadfile.close();
}

double* NNetwork::run(double runinputs[])
{
  // Load the inputs into the input layer and activate
  ilayer->inputs = runinputs;
  ilayer->activate();
  
  // Activate each layer in turn
  for (int i = 0; i < nlayers; i++)
    {
      layers[i]->activate();
    }
  
  // Activate the output layer
  olayer->activate();
  
  // Grab the outputs from the last layer
  for (int i = 0; i < olayer->size(); i++)
    {
      outputs[i] = (*olayer)[i]->output;
    }
  
  return outputs;
}
  
double* NNetwork::train(double in[], double out[])
{
  // Run the network
  this->run(in);
  
  // Train the output layer
  olayer->train(out);
  
  // Train each hidden layer in reverse order
  for (int i = nlayers - 1; i >= 0; i--)
    {
      layers[i]->train();
    }
  
  return outputs;
}

// Return the output pointer
double* NNetwork::getOutput()
{
  return outputs;
}

NNetwork::~NNetwork()
{
  // Remove previously allocated array
  delete [] outputs;
  delete [] layers;
  delete ilayer;
  delete olayer;
}

// Save the neural network
void NNetwork::save(char filename[])
{
  ofstream savefile;
  savefile.open(filename);
  
  // Output neural network attributes
  savefile << "Inputs:  " << numin   << endl;
  savefile << "Outputs: " << numout  << endl;
  savefile << "HLayers: " << nlayers << endl;
  savefile << "LRate:   " << lrate   << endl << endl;
  
  // Output each hidden layer
  for (int i = 0; i < nlayers; i++)
    {
      layers[i]->save(&savefile);
    }
  
  // Output the output layer
  olayer->save(&savefile);
  
  savefile.close();
}
